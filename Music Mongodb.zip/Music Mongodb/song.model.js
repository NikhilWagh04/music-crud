import { timeStamp } from "console";
import mongoose from "mongoose";
import { type } from "os";

const Songschema = mongoose.Schema({
    name:{
        type : String,
        unique : true
    },
    film : String,
    director : String,
    singer : String
},{timeStamp:true});

export const Song = mongoose.model("Song",Songschema)