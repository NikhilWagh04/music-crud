import express from "express"
import mongoose from "mongoose"
import dotenv from "dotenv"
import { Song } from "./song.model.js"

const app = express();

app.set("view engine","ejs")
app.use(express.json());
app.use(express.urlencoded({extended:true}));
dotenv.config({path:".env"});


const Mongoconnect = async()=>{
    try{
        const Mongoinst = await mongoose.connect(process.env.Mongo_URL)
        console.log("Connected to database with host id : ",Mongoinst.connection.host);
    }
    catch(err){
        console.log(err);
        process.exit(1);
    }
}

Mongoconnect();

app.get("/",(req,res)=>{
    res.render('landing.ejs');
});

app.post("/register", async (req, res) => {
    const { Songname, Film, Director, Singer } = req.body;
    console.log(req.body);

    try {
        const songExists = await Song.findOne({ name: Songname });
        if (songExists) {
            console.log("Song already exists");
            return res.status(200).send("Song already exists");
        } else {
            const songCreated = await Song.create({
                name: Songname,
                film: Film,
                director: Director,
                singer: Singer
            });
            console.log("Song created successfully");
        }
        res.redirect('/displaytable');
    } catch (error) {
        console.error("Error creating song:", error);
        res.status(500).send("Internal Server Error");
    }
});

app.get('/song/director/:musicdir',async(req,res)=>{
    const reqdir = req.params.musicdir;
    const reqsongs = await Song.find({director : reqdir});
    try{
    if(reqsongs.length === 0){
        res.err(404).send(`No Song of ${reqdir} found`)
    }
    else{
        res.render('display.ejs',{song : reqsongs});
    }}catch(err){
        console.log(err);
        res.status(500).send("error in finding song");
    }
})

app.get('/songs/:musicdir/:singer',async(req,res)=>{
    const reqdir = req.params.musicdir;
    const reqsgr = req.params.singer;

    const reqsongs = await Song.find({director : reqdir,singer : reqsgr});
    try{
    if(reqsongs.length === 0){
        res.status(404).send(`No Song of Music Director ${reqdir} & Singer ${reqsgr} found`)
    }
    else{
        res.render('display.ejs',{song : reqsongs});
    }}catch(err){
        console.log(err);
        res.status(500).send("error in finding song");
    }
})

app.get('/song/:singer/:film',async(req,res)=>{
        const reqsinger = req.params.singer;
        const reqfilm = req.params.film;
    const reqsongs = await Song.find({singer : reqsinger,film : reqfilm});
    try{
    if(reqsongs.length === 0){
        res.status(404).send(`No Song of Singer ${reqsinger} & Film ${reqfilm} found`)
    }
    else{
        res.render('display.ejs',{song : reqsongs});
    }}catch(err){
        console.log(err);
        res.status(500).send("error in finding song");
    }
})

app.post('/delete',async(req,res)=>{
    const{name}=req.body;

    await Song.deleteOne({name : name});
    res.redirect('/displaytable');
})
app.get("/displaytable",async(req,res)=>{
    const songs = await Song.find();
    console.log("Students found");
    res.render('display.ejs',{song : songs});
})

const port = process.env.PORT || 4000;
app.listen(port,(req,res)=>{
    console.log(`Server running on http://localhost:${port}`)
})